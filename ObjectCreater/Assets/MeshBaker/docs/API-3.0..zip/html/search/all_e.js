var searchData=
[
  ['packingalgorithm',['packingAlgorithm',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner.html#a45f321e081f67ffec99b46d9bca9e321',1,'DigitalOpus.MB.Core.MB3_TextureCombiner.packingAlgorithm()'],['../class_m_b3___texture_baker.html#a1d40d7dc518b36c754c8343cda7c52e3',1,'MB3_TextureBaker.packingAlgorithm()']]],
  ['prefabonly',['prefabOnly',['../namespace_digital_opus_1_1_m_b_1_1_core.html#a5ba05a8353f1a501abcfc71c15ce0a0aad69e089f38b1dc0ca132a4c696d268cb',1,'DigitalOpus::MB::Core']]],
  ['prefabuvrects',['prefabUVRects',['../class_m_b2___texture_bake_results.html#af1b5bc5755e084b8409d865e011711e3',1,'MB2_TextureBakeResults']]],
  ['preserve_5fcurrent_5flightmapping',['preserve_current_lightmapping',['../namespace_digital_opus_1_1_m_b_1_1_core.html#a7c6398a07657fe2d755d25429858086ca493573de4d5e57f230f3061abdc012f2',1,'DigitalOpus::MB::Core']]],
  ['preservelightmapping',['preserveLightmapping',['../class_m_b3___mesh_baker_editor_window.html#a61bb3655f1c25d1e17200928fc7fd581a37f24e93fba6e96fced462324f4958c2',1,'MB3_MeshBakerEditorWindow']]],
  ['progressupdatedelegate',['ProgressUpdateDelegate',['../namespace_digital_opus_1_1_m_b_1_1_core.html#a010baff935764e19e32134ce62295921',1,'DigitalOpus::MB::Core']]]
];
