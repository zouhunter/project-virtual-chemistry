var searchData=
[
  ['warn',['Warn',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b2___log.html#ab4326eb8cc39babe86d0bc80abd1097d',1,'DigitalOpus.MB.Core.MB2_Log.Warn()'],['../class_digital_opus_1_1_m_b_1_1_core_1_1_object_log.html#ab9337304dec20cc4f31ee240492d447c',1,'DigitalOpus.MB.Core.ObjectLog.Warn()']]]
];
