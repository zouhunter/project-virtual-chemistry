var searchData=
[
  ['maxtilingbakesize',['maxTilingBakeSize',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner.html#afd77f87ab2c038196602324675404c4f',1,'DigitalOpus.MB.Core.MB3_TextureCombiner.maxTilingBakeSize()'],['../class_m_b3___texture_baker.html#ac968c79d2cf1903258437dcfdd98f6bf',1,'MB3_TextureBaker.maxTilingBakeSize()']]],
  ['maxvertsinmesh',['maxVertsInMesh',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___multi_mesh_combiner.html#a8343ec8d64055248d66b14e4d0d5bcd3',1,'DigitalOpus::MB::Core::MB3_MultiMeshCombiner']]],
  ['meshcombiner',['meshCombiner',['../class_m_b3___mesh_baker.html#a09dffc357ed0774014b3501b7a06ebd7',1,'MB3_MeshBaker.meshCombiner()'],['../class_m_b3___mesh_baker_common.html#a7b3753d117e386b0562b82f3f050c9e1',1,'MB3_MeshBakerCommon.meshCombiner()'],['../class_m_b3___multi_mesh_baker.html#abec51899a92d0b46330cd012b7221717',1,'MB3_MultiMeshBaker.meshCombiner()']]]
];
