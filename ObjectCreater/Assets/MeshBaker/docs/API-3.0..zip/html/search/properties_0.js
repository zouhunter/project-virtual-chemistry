var searchData=
[
  ['atlaspadding',['atlasPadding',['../class_digital_opus_1_1_m_b_1_1_core_1_1_m_b3___texture_combiner.html#a53784838949c813ce53130927e45e305',1,'DigitalOpus.MB.Core.MB3_TextureCombiner.atlasPadding()'],['../class_m_b3___texture_baker.html#a03c431b1717f386f2d1294ca0524629c',1,'MB3_TextureBaker.atlasPadding()']]]
];
